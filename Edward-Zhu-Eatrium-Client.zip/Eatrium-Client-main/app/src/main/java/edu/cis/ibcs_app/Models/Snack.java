package edu.cis.ibcs_app.Models;

import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.widget.Toolbar;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Random;
import java.util.regex.Pattern;

import edu.cis.ibcs_app.Controllers.RecyclerViewAdapter;
import edu.cis.ibcs_app.Controllers.RecyclerViewInterface;
import edu.cis.ibcs_app.R;
import edu.cis.ibcs_app.Utils.CISConstants;

public class Snack extends Fragment implements RecyclerViewInterface {

    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "userID";

    // TODO: Rename and change types of parameters
    private String userID;
    private String menu;

    RecyclerViewAdapter adapter;

    ArrayList<MenuItemModel> items = new ArrayList<>();

    public Snack(String userID) {
        this.userID=userID;
        // Required empty public constructor
    }

    // TODO: Rename and change types and number of parameters
    public static Snack newInstance(String userID) {
        Snack fragment = new Snack(userID);
//        Log.d("test 3", menu);
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1,userID);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        if (getArguments() != null) {
            userID=getArguments().getString(ARG_PARAM1);
        }
        super.onCreate(savedInstanceState);
    }

    private void setUpItems(){
        ArrayList<ArrayList<String> > itemsString = processMenuString(menu);
        if(userID.equals("admin")) items.add(new MenuItemModel("Add new item", "Hold each menu item to remove", -1.0, "", -1, "", new ArrayList<Double>()));
        for(ArrayList<String> item : itemsString){
            items.add(new MenuItemModel(item.get(0), item.get(1), Double.parseDouble(item.get(2)), item.get(3), Integer.parseInt(item.get(4)), item.get(5), processNutrition(item.get(6))));
        }
    }

    public void getMenuItems(){
        try{
            Request req = new Request(CISConstants.GET_MENU);
            menu = SimpleClient.makeRequest(CISConstants.HOST, req);
        }
        catch(Exception err){
            Toast messageToUser = Toast.makeText(getContext(), "Error: "+err.toString(), Toast.LENGTH_LONG);
            messageToUser.show();
        }
    }

    public static ArrayList<Double> processNutrition(String nutrition){
        ArrayList<Double> out = new ArrayList<>();
        String[] temp = nutrition.split(", ");
        for(int i=0;i<temp.length; i++){
            out.add(Double.parseDouble(temp[i]));
        }
        return out;
    }

    public static ArrayList<ArrayList<String> > processMenuString(String menuString){
        ArrayList<ArrayList<String> > items = new ArrayList<>();
        String[] itemStrings = menuString.split("\\}");
        for (int i = 0; i < itemStrings.length; i++) {
            String itemString = itemStrings[i];
            if(!itemString.contains("snack")){
                continue;
            }
            ArrayList<String> output = new ArrayList<>();
            String[] temp = itemString.split(",");
            for (int j = 0; j < temp.length; j++) {
                if (j == 2 || j == 4) output.add(temp[j].substring(temp[j].indexOf("=") + 1));
                else if(j>=6){
                    output.add(temp[j].substring(temp[j].indexOf("=") + 2));
                }
                else{
                    output.add(temp[j].substring(temp[j].indexOf("=") + 2, temp[j].length() - 1));
                }
            }
            items.add(output);
        }
        return items;
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_snack, container, false);
        Toolbar toolbar = getActivity().findViewById(R.id.toolbar);
        toolbar.setTitle("Snack Menu");
        return view;
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        getMenuItems();
        setUpItems();
        TextView noItems = view.findViewById(R.id.noItemsSnack);
        noItems.setVisibility(View.INVISIBLE);
        if(items.size()==0){
            noItems.setVisibility(View.VISIBLE);
        }
        RecyclerView recyclerView = view.findViewById(R.id.recycler);
        adapter = new RecyclerViewAdapter(getContext(), items,this);
        recyclerView.setAdapter(adapter);
        recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));
    }

    @Override
    public void onItemClick(int position) {

        if(position==0 && userID.equals("admin")){
            CreateMenuItemFragment createMenuItemFragment = CreateMenuItemFragment.newInstance("snack");
            getActivity().getSupportFragmentManager().beginTransaction().replace(R.id.fragment_container, createMenuItemFragment).commit();
        }
        else if(!userID.equals("admin")) {
            try {
                Request req = new Request(CISConstants.PLACE_ORDER);
                req.addParam(CISConstants.ITEM_NAME_PARAM, items.get(position).getItemName());
                Random rand = new Random();
                int id = rand.nextInt(1001);
                req.addParam(CISConstants.ORDER_ID_PARAM, Integer.toString(id));
                req.addParam(CISConstants.USER_ID_PARAM, userID);
                req.addParam(CISConstants.ORDER_TYPE_PARAM, "snack");

                req.addParam(CISConstants.ITEM_ID_PARAM, items.get(position).getItemId());
                String out = SimpleClient.makeRequest(CISConstants.HOST, req);
                if (out.equals("success")) {
                    items.get(position).setAmountAvailable(-1);
                    adapter.notifyItemChanged(position);
                }
                Toast messageToUser = Toast.makeText(getContext(), "Message: " + out, Toast.LENGTH_SHORT);
                messageToUser.show();
            } catch (Exception err) {
                Toast messageToUser = Toast.makeText(getContext(), "Error: " + err.toString(), Toast.LENGTH_SHORT);
                messageToUser.show();
            }
        }
    }

    @Override
    public void onItemLongClick(int position) {
        if(userID.equals("admin") && position!=0){
            try{
                Request req = new Request(CISConstants.DELETE_MENU_ITEM);
                req.addParam(CISConstants.ITEM_NAME_PARAM, items.get(position).getItemName());
                String out = SimpleClient.makeRequest(CISConstants.HOST,req);
                if(out.equals("success")){
                    items.remove(position);
                    adapter.notifyItemRemoved(position);
                }
                Toast messageToUser = Toast.makeText(getContext(), "Message: "+out,Toast.LENGTH_SHORT);
                messageToUser.show();
            }
            catch(Exception err){
                Toast messageToUser = Toast.makeText(getContext(), "Error: "+err.toString(), Toast.LENGTH_SHORT);
                messageToUser.show();
            }
        }
    }
}