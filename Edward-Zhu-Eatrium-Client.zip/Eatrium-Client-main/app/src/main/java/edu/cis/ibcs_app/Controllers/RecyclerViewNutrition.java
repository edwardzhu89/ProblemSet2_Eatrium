package edu.cis.ibcs_app.Controllers;

import android.annotation.SuppressLint;
import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

import edu.cis.ibcs_app.Models.CISUser;
import edu.cis.ibcs_app.Models.MenuItemModel;
import edu.cis.ibcs_app.R;

public class RecyclerViewNutrition extends RecyclerView.Adapter<RecyclerViewNutrition.MyViewHolder> {

    private final RecyclerViewInterface recyclerViewInterface;

    Context context;
    ArrayList<MenuItemModel> items;

    public RecyclerViewNutrition(Context context, ArrayList<MenuItemModel> menuItems, RecyclerViewInterface recyclerViewInterface){
        this.context = context;
        this.items = menuItems;
        this.recyclerViewInterface=recyclerViewInterface;
    }

    @NonNull
    @Override
    public RecyclerViewNutrition.MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(context);
        View view = inflater.inflate(R.layout.calc_recycler_view_row, parent, false);
        return new RecyclerViewNutrition.MyViewHolder(view, recyclerViewInterface);
    }

    @SuppressLint("SetTextI18n")
    @Override
    public void onBindViewHolder(@NonNull RecyclerViewNutrition.MyViewHolder holder, @SuppressLint("RecyclerView") final int position) {

        holder.name.setText(items.get(position).getItemName());
        holder.calorie.setText("Calories: "+Double.toString(items.get(position).getNutrition().get(0)));
        holder.protein.setText("Protein: "+Double.toString(items.get(position).getNutrition().get(1)));
        holder.carbs.setText("Carbs: "+Double.toString(items.get(position).getNutrition().get(2)));
    }

    @Override
    public int getItemCount() {

        return items.size();
    }

    public static class MyViewHolder extends RecyclerView.ViewHolder{

        TextView name, calorie, protein, carbs;

        public MyViewHolder(@NonNull View itemView, final RecyclerViewInterface recyclerViewInterface) {
            super(itemView);

            name = itemView.findViewById(R.id.name);
            calorie = itemView.findViewById(R.id.calorieCount);
            protein = itemView.findViewById(R.id.proteinCount);
            carbs = itemView.findViewById(R.id.carbCount);

            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    if(recyclerViewInterface != null){
                        int position = getAdapterPosition();
                        if(position!=RecyclerView.NO_POSITION){
                            recyclerViewInterface.onItemClick(position);
                        }
                    }
                }
            });

            itemView.setOnLongClickListener(new View.OnLongClickListener(){
                @Override
                public boolean onLongClick(View view) {
                    if(recyclerViewInterface != null){
                        int position = getAdapterPosition();
                        if(position!=RecyclerView.NO_POSITION){
                            recyclerViewInterface.onItemLongClick(position);
                        }
                    }
                    return true;
                }
            });
        }
    }
}
