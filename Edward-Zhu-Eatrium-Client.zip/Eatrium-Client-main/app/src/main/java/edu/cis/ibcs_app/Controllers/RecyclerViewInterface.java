package edu.cis.ibcs_app.Controllers;

public interface RecyclerViewInterface {

    void onItemClick(int position);
    void onItemLongClick(int position);

}
