package edu.cis.ibcs_app.Models;

import android.content.Intent;
import android.os.Bundle;

import androidx.appcompat.widget.Toolbar;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import edu.cis.ibcs_app.CISUserActivity;
import edu.cis.ibcs_app.R;
import edu.cis.ibcs_app.Utils.CISConstants;

public class UserLoginFragment extends Fragment {


    public UserLoginFragment() {
        // Required empty public constructor
    }
    // TODO: Rename and change types and number of parameters
    public static UserLoginFragment newInstance() {
        UserLoginFragment fragment = new UserLoginFragment();
        Bundle args = new Bundle();
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        final View rootView = inflater.inflate(R.layout.fragment_user_login, container, false);

        Button createUser = rootView.findViewById(R.id.createNewUserButton);
        createUser.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                EditText userName=rootView.findViewById(R.id.newUserName);
                EditText userId = rootView.findViewById(R.id.newUserID);
                EditText yearLevel = rootView.findViewById(R.id.newUserYear);
                try{
                    Request req = new Request(CISConstants.CREATE_USER);
                    req.addParam(CISConstants.USER_NAME_PARAM, userName.getText().toString());
                    req.addParam(CISConstants.USER_ID_PARAM, userId.getText().toString());
                    req.addParam(CISConstants.YEAR_LEVEL_PARAM, yearLevel.getText().toString());

                    String resultAddUser = SimpleClient.makeRequest(CISConstants.HOST, req);
                    Toast messageToUser = Toast.makeText(getContext(), "Message: "+resultAddUser,Toast.LENGTH_LONG);
                    messageToUser.show();
                    if(resultAddUser.contains("success")){
                        Intent nextScreen = new Intent(getContext(), CISUserActivity.class);
                        Bundle b = new Bundle();
                        b.putString("userId",userId.getText().toString());
                        nextScreen.putExtras(b);
                        startActivity(nextScreen);
                    }
                }
                catch(Exception err){
                    Toast messageToUser = Toast.makeText(getContext(), "Error: "+err.toString(), Toast.LENGTH_LONG);
                    messageToUser.show();
                }
            }
        });

        Button login = rootView.findViewById(R.id.loginButton);
        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                EditText userId = rootView.findViewById(R.id.existingUserID);
                try{
                    Request req = new Request(CISConstants.GET_USER);
                    req.addParam(CISConstants.USER_ID_PARAM, userId.getText().toString());

                    String resultAddUser = SimpleClient.makeRequest(CISConstants.HOST, req);

                    if(!resultAddUser.contains(CISConstants.USER_INVALID_ERR)){
                        Toast messageToUser = Toast.makeText(getContext(), "Logged in as "+userId.getText().toString(),Toast.LENGTH_LONG);
                        messageToUser.show();
                        Intent nextScreen = new Intent(getContext(), CISUserActivity.class);
                        Bundle b = new Bundle();
                        b.putString("userId",userId.getText().toString());
                        nextScreen.putExtras(b);
                        startActivity(nextScreen);
                    }
                    else{
                        Toast messageToUser = Toast.makeText(getContext(), "Message: "+resultAddUser,Toast.LENGTH_LONG);
                        messageToUser.show();
                    }
                }
                catch(Exception err){
                    Toast messageToUser = Toast.makeText(getContext(), "Error: "+err.toString(), Toast.LENGTH_LONG);
                    messageToUser.show();
                }
            }
        });

        return rootView;
    }
}