package edu.cis.ibcs_app.Models;

import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.widget.Toolbar;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

import edu.cis.ibcs_app.Controllers.RecyclerViewAdapter;
import edu.cis.ibcs_app.Controllers.RecyclerViewInterface;
import edu.cis.ibcs_app.Controllers.RecyclerViewInterface2;
import edu.cis.ibcs_app.Controllers.RecyclerViewNutrition;
import edu.cis.ibcs_app.Controllers.RecyclerViewNutrition2;
import edu.cis.ibcs_app.R;
import edu.cis.ibcs_app.Utils.CISConstants;

public class NutritionFragment extends Fragment implements RecyclerViewInterface, RecyclerViewInterface2 {

    private String menu;
    ArrayList<MenuItemModel> items = new ArrayList<>();
    ArrayList<MenuItemModel> orders = new ArrayList<>();
    RecyclerViewNutrition adapter;
    RecyclerViewNutrition2 adapter2;

    double protein=0.0;
    double carbs = 0.0;
    double cals=0.0;

    TextView proteinText;
    TextView carbsText;
    TextView calsText;

    Button clear;

    public NutritionFragment() {
        // Required empty public constructor
    }

    public static NutritionFragment newInstance() {
        NutritionFragment fragment = new NutritionFragment();
        Bundle args = new Bundle();
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_nutrition, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        calsText=view.findViewById(R.id.calorieValue);
        proteinText=view.findViewById(R.id.proteinValue);
        carbsText=view.findViewById(R.id.carbValue);
        clear = view.findViewById(R.id.clear);

        clear.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                orders.clear();
                carbs=0;
                protein=0;
                cals=0;
                adapter2.notifyDataSetChanged();
                carbsText.setText("Carbohydrates: 0.0g");
                proteinText.setText("Protein: 0.0g");
                calsText.setText("Calories: 0.0kcal");
            }
        });

        getMenuItems();
        setUpItems();

        Toolbar toolbar = getActivity().findViewById(R.id.toolbar);
        toolbar.setTitle("Nutrition Calculator");

        RecyclerView recyclerView = view.findViewById(R.id.recycler);
        adapter = new RecyclerViewNutrition(getContext(), items,this);
        recyclerView.setAdapter(adapter);
        recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));

        RecyclerView recyclerView2 = view.findViewById(R.id.recycler2);
        adapter2 = new RecyclerViewNutrition2(getContext(), orders,this);
        recyclerView2.setAdapter(adapter2);
        recyclerView2.setLayoutManager(new LinearLayoutManager(getContext()));
    }

    private void setUpItems(){
        ArrayList<ArrayList<String>> itemsString = processMenuString(menu);
        for(ArrayList<String> item : itemsString){
            Log.d("itemstring", item.toString());
            items.add(new MenuItemModel(item.get(0), item.get(1), Double.parseDouble(item.get(2)), item.get(3), Integer.parseInt(item.get(4)), item.get(5), processNutrition(item.get(6))));
        }
    }

    public void getMenuItems(){
        try{
            Request req = new Request(CISConstants.GET_MENU);
            menu = SimpleClient.makeRequest(CISConstants.HOST, req);
        }
        catch(Exception err){
            Toast messageToUser = Toast.makeText(getContext(), "Error: "+err.toString(), Toast.LENGTH_LONG);
            messageToUser.show();
        }
    }

    public static ArrayList<Double> processNutrition(String nutrition){
        Log.d("test test test", nutrition);
        ArrayList<Double> out = new ArrayList<>();
        String[] temp = nutrition.split(", ");
        for(int i=0;i<temp.length; i++){
            out.add(Double.parseDouble(temp[i]));
        }
        return out;
    }

    public static ArrayList<ArrayList<String> > processMenuString(String menuString){
        Log.d("test test test test", menuString);
        ArrayList<ArrayList<String> > items = new ArrayList<>();
        String[] itemStrings = menuString.split("\\}");
        Log.d("size", String.valueOf(itemStrings.length));
        for (int i = 0; i < itemStrings.length; i++) {
            String itemString = itemStrings[i];
            if(itemString.length()==0){
                continue;
            }
            Log.d("each item", itemString);
            ArrayList<String> output = new ArrayList<>();
            String[] temp = itemString.split(",");
            for (int j = 0; j < temp.length; j++) {
                if (j == 2 || j == 4) output.add(temp[j].substring(temp[j].indexOf("=") + 1));
                else if(j>=6){
                    continue;
                }
                else if(temp[j].length()>=1){
                    output.add(temp[j].substring(temp[j].indexOf("=") + 2, temp[j].length() - 1));
                }
            }
            if(itemString.length()!=0)output.add(itemString.substring( itemString.indexOf("{", itemString.indexOf("{")+1)+1 ));
            items.add(output);
        }
        return items;
    }

    @Override
    public void onItemClick(int position) {

        orders.add(items.get(position));
        adapter2.notifyItemChanged(position);
        cals+=items.get(position).getNutrition().get(0);
        protein+=items.get(position).getNutrition().get(1);
        carbs+=items.get(position).getNutrition().get(2);

        carbsText.setText("Carbohydrates: "+String.valueOf(carbs)+"g");
        proteinText.setText("Protein: "+String.valueOf(protein)+"g");
        calsText.setText("Calories: "+String.valueOf(cals)+"kcal");
    }

    @Override
    public void onItemLongClick(int position) {

    }

    @Override
    public void onItemClick2(int position) {

    }

    @Override
    public void onItemLongClick2(int position) {
        Log.d("nutrition selection", String.valueOf(position));
        cals-=orders.get(position).getNutrition().get(0);
        protein-=orders.get(position).getNutrition().get(1);
        carbs-=orders.get(position).getNutrition().get(2);

        orders.remove(position);
        adapter2.notifyItemRemoved(position);

        carbsText.setText("Carbohydrates: "+String.valueOf(carbs)+"g");
        proteinText.setText("Protein: "+String.valueOf(protein)+"g");
        calsText.setText("Calories: "+String.valueOf(cals)+"kcal");

    }
}