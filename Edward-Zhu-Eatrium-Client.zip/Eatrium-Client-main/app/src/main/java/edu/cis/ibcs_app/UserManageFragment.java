package edu.cis.ibcs_app;

import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.widget.Toolbar;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

import edu.cis.ibcs_app.Controllers.RecyclerViewAdapterAdmin;
import edu.cis.ibcs_app.Controllers.RecyclerViewInterface;
import edu.cis.ibcs_app.Models.CISUser;
import edu.cis.ibcs_app.Models.Request;
import edu.cis.ibcs_app.Models.SimpleClient;
import edu.cis.ibcs_app.Utils.CISConstants;

public class UserManageFragment extends Fragment implements RecyclerViewInterface {

    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER

    // TODO: Rename and change types of parameters
    private String users;

    ArrayList<CISUser> usersList = new ArrayList<>();

    RecyclerViewAdapterAdmin adapter;

    public UserManageFragment() {
        // Required empty public constructor
    }

    // TODO: Rename and change types and number of parameters
    public static UserManageFragment newInstance() {
        UserManageFragment fragment = new UserManageFragment();
        Bundle args = new Bundle();
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        getUsers();
        super.onCreate(savedInstanceState);
    }

    private void setUpItems(){
        ArrayList<ArrayList<String> > itemsString = process(users);
        if(itemsString==null){
            return;
        }
        for(ArrayList<String> item : itemsString){
            CISUser newUser = new CISUser(item.get(1), item.get(0), item.get(2), Double.parseDouble(item.get(item.size()-1)), item.size()-4);
            if(item.get(3).equals("")){
                newUser.setOrders(0);
            }
            usersList.add(newUser);
        }
    }

    public static ArrayList<ArrayList<String> > process(String usersString){
        ArrayList<ArrayList<String> > out = new ArrayList<>();
        if(usersString.equals("")){
            return out;
        }
        ArrayList<String> tempUser = new ArrayList<>();
        while(!usersString.equals("}") ) {
            String temp = usersString.substring(0, usersString.indexOf('\'', usersString.indexOf('\'') + 1) + 1);
            if (usersString.startsWith(", orders= ,")) {
                tempUser.add("");
                usersString = usersString.substring(usersString.indexOf("=") + 2);
            } else if (usersString.startsWith(", orders=") || usersString.startsWith("Order")) {
                tempUser.add(usersString.substring(usersString.indexOf("{") + 1, usersString.indexOf("}")));
                usersString = usersString.substring(usersString.indexOf("}") + 1);
            } else if (usersString.startsWith(", money=")) {
                tempUser.add(usersString.substring(usersString.indexOf("=") + 1, usersString.indexOf("}")));
                usersString = usersString.substring(usersString.indexOf("}"));
                System.out.println(tempUser);
                out.add(tempUser);
                tempUser = new ArrayList<>();
            } else {
                tempUser.add(temp.substring(temp.indexOf('\'') + 1, temp.indexOf('\'', temp.indexOf('\'') + 1)));
                usersString = usersString.substring(usersString.indexOf('\'', usersString.indexOf('\'') + 1) + 1);
            }
        }
        return out;
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_user_manage, container, false);
        Toolbar toolbar = getActivity().findViewById(R.id.toolbar);
        toolbar.setTitle("Manage Users");
        return view;
    }

    public void getUsers(){
        try{
            Request req = new Request(CISConstants.GET_ALL_USERS);
            users = SimpleClient.makeRequest(CISConstants.HOST, req);
            Log.d("users 0", users);
        }
        catch(Exception err){
            Toast messageToUser = Toast.makeText(getContext(), "Error: "+err.toString(), Toast.LENGTH_LONG);
            messageToUser.show();
        }
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        setUpItems();
        TextView noUsers = view.findViewById(R.id.noItemsLunch);
        noUsers.setVisibility(View.INVISIBLE);
        if(usersList.size()==0){
            noUsers.setVisibility(View.VISIBLE);
        }
        RecyclerView recyclerView = view.findViewById(R.id.recycler);
        adapter = new RecyclerViewAdapterAdmin(getContext(), usersList, this);
        recyclerView.setAdapter(adapter);
        recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));
    }

    @Override
    public void onItemClick(int position) {

    }

    @Override
    public void onItemLongClick(int position) {

    }
}