package edu.cis.ibcs_app.Controllers;

import android.annotation.SuppressLint;
import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

import edu.cis.ibcs_app.Models.CISUser;
import edu.cis.ibcs_app.R;

public class RecyclerViewAdapterAdmin extends RecyclerView.Adapter<RecyclerViewAdapterAdmin.MyViewHolder> {

    private final RecyclerViewInterface recyclerViewInterface;

    Context context;
    ArrayList<CISUser> userList;

    public RecyclerViewAdapterAdmin(Context context, ArrayList<CISUser> userList, RecyclerViewInterface recyclerViewInterface){
        this.context = context;
        this.userList = userList;
        this.recyclerViewInterface=recyclerViewInterface;
    }

    @NonNull
    @Override
    public RecyclerViewAdapterAdmin.MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(context);
        View view = inflater.inflate(R.layout.user_recycler_view_row, parent, false);
        return new RecyclerViewAdapterAdmin.MyViewHolder(view, recyclerViewInterface);
    }

    @SuppressLint("SetTextI18n")
    @Override
    public void onBindViewHolder(@NonNull RecyclerViewAdapterAdmin.MyViewHolder holder, int position) {

        Log.d("recyclerviewtest", userList.get(position).toString());

        holder.name.setText(userList.get(position).getUserName());
        holder.userId.setText("User ID: "+userList.get(position).getUserId());
        holder.yearLevel.setText("Year Level: "+userList.get(position).getYearLevel());
        holder.money.setText("$"+Double.toString(userList.get(position).getMoney()));
        holder.orders.setText("No. Orders: "+Integer.toString(userList.get(position).getOrders()));

    }

    @Override
    public int getItemCount() {

        return userList.size();
    }

    public static class MyViewHolder extends RecyclerView.ViewHolder{

        TextView name, userId, money, yearLevel, orders;

        public MyViewHolder(@NonNull View itemView, final RecyclerViewInterface recyclerViewInterface) {
            super(itemView);

            name = itemView.findViewById(R.id.name);
            userId = itemView.findViewById(R.id.userId);
            money = itemView.findViewById(R.id.balance);
            yearLevel = itemView.findViewById(R.id.yearLevel);
            orders = itemView.findViewById(R.id.calorieCount);

            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    if(recyclerViewInterface != null){
                        int position = getAdapterPosition();
                        if(position!=RecyclerView.NO_POSITION){
                            recyclerViewInterface.onItemClick(position);
                        }
                    }
                }
            });

            itemView.setOnLongClickListener(new View.OnLongClickListener(){
                @Override
                public boolean onLongClick(View view) {
                    if(recyclerViewInterface != null){
                        int position = getAdapterPosition();
                        if(position!=RecyclerView.NO_POSITION){
                            recyclerViewInterface.onItemLongClick(position);
                        }
                    }
                    return true;
                }
            });
        }
    }
}
