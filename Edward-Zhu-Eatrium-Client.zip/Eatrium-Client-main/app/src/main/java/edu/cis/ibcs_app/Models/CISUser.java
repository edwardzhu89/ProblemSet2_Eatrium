package edu.cis.ibcs_app.Models;

import android.view.Menu;

import java.util.ArrayList;

public class CISUser {

    private String userName;
    private String userId;
    private String yearLevel;
    private double money;
    private int orders;

    public CISUser(String name, String id, String year, double money, int orders){

        userName=name;
        userId=id;
        yearLevel=year;
        this.money=money;
        this.orders=orders;

    }

    public CISUser(){
        userName="";
        userId="";
        yearLevel="";
        money=0;
        orders=0;
    }

    public void setUserName(String name){
        userName=name;
    }

    public void setUserId(String id){
        userId=id;
    }

    public void setOrders(int orders) {
        this.orders = orders;
    }

    public void setYearLevel(String year){
        yearLevel=year;
    }

    public void addMoney(double p){money+=p;}

    public void takeMoney(double p){
        money-=p;
    }

    public String getUserName(){
        return userName;
    }

    public String getUserId(){
        return userId;
    }

    public String getYearLevel(){
        return yearLevel;
    }

    public double getMoney(){return money;}

    public int getOrders() {
        return orders;
    }

    public String toString(){return "CISUser{userID=\'"+userId+"\', name=\'"+userName+"\', yearLevel=\'"+yearLevel+"\', orders= "+orders+", money="+money+"}";}

}