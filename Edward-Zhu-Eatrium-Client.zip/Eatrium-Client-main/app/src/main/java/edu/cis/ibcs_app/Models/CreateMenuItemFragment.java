package edu.cis.ibcs_app.Models;

import android.os.Bundle;

import androidx.appcompat.widget.Toolbar;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import edu.cis.ibcs_app.R;
import edu.cis.ibcs_app.Utils.CISConstants;

public class CreateMenuItemFragment extends Fragment {

    private String menuType;

    private static final String ARG_PARAM1 = "menuType";

    public CreateMenuItemFragment(String menuType) {
        this.menuType=menuType;
        // Required empty public constructor
    }
    // TODO: Rename and change types and number of parameters
    public static CreateMenuItemFragment newInstance(String menuType) {
        CreateMenuItemFragment fragment = new CreateMenuItemFragment(menuType);
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, menuType);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        if (getArguments() != null) {
            menuType=getArguments().getString(ARG_PARAM1);
        }
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        final View rootView = inflater.inflate(R.layout.fragment_create_menu_item, container, false);

        Toolbar toolbar = getActivity().findViewById(R.id.toolbar);
        toolbar.setTitle("Add new " + menuType+ " item");

        Button create = rootView.findViewById(R.id.create);

        create.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v){
                EditText itemName=rootView.findViewById(R.id.menuItemName);
                EditText desc = rootView.findViewById(R.id.menuItemDesc);
                EditText price = rootView.findViewById(R.id.menuItemPrice);
                EditText id = rootView.findViewById(R.id.menuItemId);

                EditText cal = rootView.findViewById(R.id.calories);
                EditText protein = rootView.findViewById(R.id.protein);
                EditText carbs = rootView.findViewById(R.id.carbs);

                try{
                    Request req = new Request(CISConstants.ADD_MENU_ITEM);
                    req.addParam(CISConstants.ITEM_NAME_PARAM, itemName.getText().toString());
                    req.addParam(CISConstants.ITEM_ID_PARAM, id.getText().toString());
                    req.addParam(CISConstants.ITEM_TYPE_PARAM, menuType);
                    req.addParam(CISConstants.PRICE_PARAM, price.getText().toString());
                    req.addParam(CISConstants.DESC_PARAM, desc.getText().toString());

                    String nutrition=cal.getText().toString() + ", " + protein.getText().toString() + ", "+ carbs.getText().toString();
                    req.addParam(CISConstants.NUTRITION, nutrition);

                    String resultAddItem = SimpleClient.makeRequest(CISConstants.HOST, req);
                    Toast messageToUser = Toast.makeText(getContext(), "Message: "+resultAddItem,Toast.LENGTH_LONG);
                    messageToUser.show();

                    if(resultAddItem.contains("success")){
                        if(menuType.equals("lunch")){
                            Lunch lunch = Lunch.newInstance("admin");
                            getActivity().getSupportFragmentManager().beginTransaction().replace(R.id.fragment_container, lunch).commit();
                        }
                        else if(menuType.equals("snack")){
                            Snack snack = Snack.newInstance("admin");
                            getActivity().getSupportFragmentManager().beginTransaction().replace(R.id.fragment_container, snack).commit();
                        }
                        else{
                            Breakfast breakfast = Breakfast.newInstance("admin");
                            getActivity().getSupportFragmentManager().beginTransaction().replace(R.id.fragment_container, breakfast).commit();
                        }
                    }

                }
                catch(Exception err){
                    Toast messageToUser = Toast.makeText(getContext(), "Error: "+err.toString(), Toast.LENGTH_LONG);
                    messageToUser.show();
                }
            }
        });

        return rootView;
    }
}