package edu.cis.ibcs_app.Models;

import android.annotation.SuppressLint;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.widget.Toolbar;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Locale;
import java.util.Random;

import edu.cis.ibcs_app.Controllers.RecyclerViewAdapter;
import edu.cis.ibcs_app.Controllers.RecyclerViewInterface;
import edu.cis.ibcs_app.R;
import edu.cis.ibcs_app.Utils.CISConstants;

public class Orders extends Fragment implements RecyclerViewInterface {

    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "userID";

    // TODO: Rename and change types of parameters
    private String cart;
    private String userID;

    ArrayList<MenuItemModel> items = new ArrayList<>();

    RecyclerViewAdapter adapter;

    public Orders(String userID) {
        this.userID=userID;
        // Required empty public constructor
    }

    // TODO: Rename and change types and number of parameters
    public static Orders newInstance(String userID) {
        Orders fragment = new Orders(userID);
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, userID);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        if (getArguments() != null) {
            userID = getArguments().getString(ARG_PARAM1);
        }
        getCart();
        Log.d("orders test",cart);
        super.onCreate(savedInstanceState);
    }

    private void setUpItems(){
        ArrayList<ArrayList<String> > itemsString = processCartString(cart);
        if(itemsString==null){
            return;
        }
        for(ArrayList<String> item : itemsString){
            items.add(new MenuItemModel(item.get(3), item.get(1).toUpperCase(Locale.ROOT)+" Order", 0.0, item.get(0), -1, item.get(1), item.get(2)));
        }
    }

    public static ArrayList<ArrayList<String> > processCartString(String cartString){
        ArrayList<ArrayList<String> > items = new ArrayList<>();
        if(cartString == null || cartString.isEmpty()){
            return null;
        }
        String[] itemStrings = cartString.split("\\}");
        for(int i=0; i < itemStrings.length; i++){
            String itemString = itemStrings[i];
            ArrayList<String> output = new ArrayList<>();
            String[] temp = itemString.split(",");
            for(int j=0;j<4;j++){
                output.add(temp[j].substring(temp[j].indexOf("=")+2, temp[j].length()-1));
            }
            items.add(output);
        }
        return items;
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_orders, container, false);
        Toolbar toolbar = getActivity().findViewById(R.id.toolbar);
        toolbar.setTitle("Your Orders");
        return view;
    }

    public void getCart(){
        try{
            Request req = new Request(CISConstants.GET_CART);
            req.addParam(CISConstants.USER_ID_PARAM, userID);
            cart = SimpleClient.makeRequest(CISConstants.HOST, req);
        }
        catch(Exception err){
            Toast messageToUser = Toast.makeText(getContext(), "Error: "+err.toString(), Toast.LENGTH_LONG);
            messageToUser.show();
        }
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        setUpItems();
        TextView noOrders = view.findViewById(R.id.noOrdersText);
        noOrders.setVisibility(View.INVISIBLE);
        if(items.size()==0){
            noOrders.setVisibility(View.VISIBLE);
        }
        RecyclerView recyclerView = view.findViewById(R.id.recycler);
        adapter = new RecyclerViewAdapter(getContext(), items, this);
        recyclerView.setAdapter(adapter);
        recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));
    }

    @Override
    public void onItemClick(int position) {

    }

    @Override
    public void onItemLongClick(int position) {
        try{
            Request req = new Request(CISConstants.DELETE_ORDER);
            req.addParam(CISConstants.USER_ID_PARAM, userID);
            req.addParam(CISConstants.ITEM_NAME_PARAM, items.get(position).getItemName());
            req.addParam(CISConstants.ORDER_TYPE_PARAM, items.get(position).getItemType());
            req.addParam(CISConstants.ORDER_ID_PARAM, items.get(position).getOrderID());
            req.addParam(CISConstants.ITEM_ID_PARAM, items.get(position).getItemId());

            String out = SimpleClient.makeRequest(CISConstants.HOST,req);
            if(out.equals("success")){
                items.remove(position);
                adapter.notifyItemRemoved(position);
            }

            Toast messageToUser = Toast.makeText(getContext(), "Message: "+out,Toast.LENGTH_SHORT);
            messageToUser.show();
        }
        catch(Exception err){
            Toast messageToUser = Toast.makeText(getContext(), "Error: "+err.toString(), Toast.LENGTH_SHORT);
            messageToUser.show();
        }
    }
}