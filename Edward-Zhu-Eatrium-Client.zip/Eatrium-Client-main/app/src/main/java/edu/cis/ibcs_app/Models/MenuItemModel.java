package edu.cis.ibcs_app.Models;

import android.widget.ArrayAdapter;

import java.util.ArrayList;

public class MenuItemModel {

    private String itemName;
    private String desc;
    private double price;
    private String itemId;
    private String itemType;
    private int amountAvailable;
    private String orderID;
    private ArrayList<Double> nutrition;

    public MenuItemModel(String itemName, String desc, double price, String itemId, int amountAvailable, String itemType, ArrayList<Double> nutrition) {
        this.itemName = itemName;
        this.desc = desc;
        this.price = price;
        this.itemId = itemId;
        this.itemType = itemType;
        this.amountAvailable = amountAvailable;
        this.nutrition=nutrition;
    }

    public MenuItemModel(String itemName, String desc, double price, String itemId, int amountAvailable, String itemType, String orderID) {
        this.itemName = itemName;
        this.desc = desc;
        this.price = price;
        this.itemId = itemId;
        this.itemType = itemType;
        this.amountAvailable = amountAvailable;
        this.orderID=orderID;
    }

    public String getItemName() {
        return itemName;
    }

    public String getOrderID() {
        return orderID;
    }

    public String getDesc() {
        return desc;
    }

    public double getPrice() {
        return price;
    }

    public String getItemId() {
        return itemId;
    }

    public ArrayList<Double> getNutrition() {
        return nutrition;
    }

    public String getItemType() {
        return itemType;
    }

    public int getAmountAvailable() {
        return amountAvailable;
    }

    public void setAmountAvailable(int x) {
        this.amountAvailable += x;
    }
}
