package edu.cis.ibcs_app.Controllers;

public interface RecyclerViewInterface2 {

    void onItemClick2(int position);
    void onItemLongClick2(int position);

}
