package edu.cis.ibcs_app;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import java.io.IOException;

import edu.cis.ibcs_app.Models.Request;
import edu.cis.ibcs_app.Models.SimpleClient;
import edu.cis.ibcs_app.R;
import edu.cis.ibcs_app.Utils.CISConstants;

public class ListingsActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_listings);

        Button button = findViewById(R.id.ping);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Request ping = new Request(CISConstants.PING);
                try {
                    String result = SimpleClient.makeRequest(CISConstants.HOST,ping);
                    System.out.println(result);
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        });
    }

}