package edu.cis.ibcs_app.Controllers;

import android.annotation.SuppressLint;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

import edu.cis.ibcs_app.Models.MenuItemModel;
import edu.cis.ibcs_app.R;

public class RecyclerViewAdapter extends RecyclerView.Adapter<RecyclerViewAdapter.MyViewHolder> {

    private final RecyclerViewInterface recyclerViewInterface;

    Context context;
    ArrayList<MenuItemModel> menuItems;

    public RecyclerViewAdapter(Context context, ArrayList<MenuItemModel> menuItems, RecyclerViewInterface recyclerViewInterface){
        this.context = context;
        this.menuItems = menuItems;
        this.recyclerViewInterface=recyclerViewInterface;
    }

    @NonNull
    @Override
    public RecyclerViewAdapter.MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(context);
        View view = inflater.inflate(R.layout.recycler_view_row, parent, false);
        return new RecyclerViewAdapter.MyViewHolder(view, recyclerViewInterface);
    }

    @SuppressLint("SetTextI18n")
    @Override
    public void onBindViewHolder(@NonNull RecyclerViewAdapter.MyViewHolder holder, int position) {

        holder.name.setText(menuItems.get(position).getItemName());
        holder.desc.setText(menuItems.get(position).getDesc());
        if(menuItems.get(position).getPrice() == 0.0){
            holder.price.setText("");
        }
        else if(menuItems.get(position).getPrice() == -1.0){
            holder.price.setText("+  ");
            holder.price.setTextSize(45.0F);
        }
        else {
            holder.price.setText("$" + Double.toString(menuItems.get(position).getPrice()));
        }
        if(menuItems.get(position).getAmountAvailable() == -1){
            holder.avail.setText("");
        }
        else{
            holder.avail.setText(Integer.toString(menuItems.get(position).getAmountAvailable())+ " in stock");
        }

    }

    @Override
    public int getItemCount() {

        return menuItems.size();
    }

    public static class MyViewHolder extends RecyclerView.ViewHolder{

        TextView name, desc, price, avail;

        public MyViewHolder(@NonNull View itemView, final RecyclerViewInterface recyclerViewInterface) {
            super(itemView);

            name = itemView.findViewById(R.id.name);
            desc = itemView.findViewById(R.id.desc);
            price = itemView.findViewById(R.id.price);
            avail = itemView.findViewById(R.id.avail);

            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    if(recyclerViewInterface != null){
                        int position = getAdapterPosition();
                        if(position!=RecyclerView.NO_POSITION){
                            recyclerViewInterface.onItemClick(position);
                        }
                    }
                }
            });

            itemView.setOnLongClickListener(new View.OnLongClickListener(){
                @Override
                public boolean onLongClick(View view) {
                    if(recyclerViewInterface != null){
                        int position = getAdapterPosition();
                        if(position!=RecyclerView.NO_POSITION){
                            recyclerViewInterface.onItemLongClick(position);
                        }
                    }
                    return true;
                }
            });
        }
    }
}
