package edu.cis.ibcs_app;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.MenuItem;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.material.navigation.NavigationView;

import edu.cis.ibcs_app.Controllers.MainActivity;
import edu.cis.ibcs_app.Models.Breakfast;
import edu.cis.ibcs_app.Models.Lunch;
import edu.cis.ibcs_app.Models.Orders;
import edu.cis.ibcs_app.Models.Request;
import edu.cis.ibcs_app.Models.SimpleClient;
import edu.cis.ibcs_app.Models.Snack;
import edu.cis.ibcs_app.Utils.CISConstants;

public class CISAdminActivity extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener {

    private DrawerLayout drawer;
    private String userID="admin";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cisadmin);

        Toolbar toolbar = findViewById(R.id.toolbar);
        toolbar.setTitle("Admin Mode");
        setSupportActionBar(toolbar);

        drawer = findViewById(R.id.drawer_layout);
        NavigationView navigationView  = findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(this);

        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawer.addDrawerListener(toggle);
        toggle.syncState();

        UserManageFragment userManageFragment = UserManageFragment.newInstance();
        getSupportFragmentManager().beginTransaction().replace(R.id.fragment_container, userManageFragment).commit();
    }

    @Override
    public void onBackPressed(){
        if(drawer.isDrawerOpen(GravityCompat.START)){
            drawer.closeDrawer(GravityCompat.START);
        }
        else{
            super.onBackPressed();
        }
    }

    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {
        switch(menuItem.getItemId()){
            case R.id.nav_breakfast:
                Breakfast breakfast = Breakfast.newInstance(userID);
                getSupportFragmentManager().beginTransaction().replace(R.id.fragment_container, breakfast).commit();
                break;
            case R.id.nav_lunch:
                Lunch lunch = Lunch.newInstance(userID);
                getSupportFragmentManager().beginTransaction().replace(R.id.fragment_container, lunch).commit();
                break;
            case R.id.nav_snack:
                Snack snack = Snack.newInstance(userID);
                getSupportFragmentManager().beginTransaction().replace(R.id.fragment_container, snack).commit();
                break;
            case R.id.nav_user:
                UserManageFragment manage = UserManageFragment.newInstance();
                getSupportFragmentManager().beginTransaction().replace(R.id.fragment_container, manage).commit();
                break;
            case R.id.nav_logout:
                Intent nextScreen = new Intent(getBaseContext(), MainActivity.class);
                startActivity(nextScreen);
                break;
        }
        drawer.closeDrawer(GravityCompat.START);
        return true;
    }
}