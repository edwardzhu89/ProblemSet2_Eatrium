package edu.cis.ibcs_app.Controllers;

import android.annotation.SuppressLint;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

import edu.cis.ibcs_app.Models.MenuItemModel;
import edu.cis.ibcs_app.R;

public class RecyclerViewNutrition2 extends RecyclerView.Adapter<RecyclerViewNutrition2.MyViewHolder> {

    private final RecyclerViewInterface2 recyclerViewInterface;

    Context context;
    ArrayList<MenuItemModel> items;

    public RecyclerViewNutrition2(Context context, ArrayList<MenuItemModel> menuItems, RecyclerViewInterface2 recyclerViewInterface){
        this.context = context;
        this.items = menuItems;
        this.recyclerViewInterface=recyclerViewInterface;
    }

    @NonNull
    @Override
    public RecyclerViewNutrition2.MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(context);
        View view = inflater.inflate(R.layout.calc_recycler_view_row_2, parent, false);
        return new RecyclerViewNutrition2.MyViewHolder(view, recyclerViewInterface);
    }

    @SuppressLint("SetTextI18n")
    @Override
    public void onBindViewHolder(@NonNull RecyclerViewNutrition2.MyViewHolder holder, @SuppressLint("RecyclerView") final int position) {

        holder.name.setText(items.get(position).getItemName());
        holder.calorie.setText("Calories: "+Double.toString(items.get(position).getNutrition().get(0)));
        holder.protein.setText("Protein: "+Double.toString(items.get(position).getNutrition().get(1)));
        holder.carbs.setText("Carbs: "+Double.toString(items.get(position).getNutrition().get(2)));
    }

    @Override
    public int getItemCount() {

        return items.size();
    }

    public static class MyViewHolder extends RecyclerView.ViewHolder{

        TextView name, calorie, protein, carbs;

        public MyViewHolder(@NonNull View itemView, final RecyclerViewInterface2 recyclerViewInterface) {
            super(itemView);

            name = itemView.findViewById(R.id.name);
            calorie = itemView.findViewById(R.id.calorieCount);
            protein = itemView.findViewById(R.id.proteinCount);
            carbs = itemView.findViewById(R.id.carbCount);

            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    if(recyclerViewInterface != null){
                        int position = getAdapterPosition();
                        if(position!=RecyclerView.NO_POSITION){
                            recyclerViewInterface.onItemClick2(position);
                        }
                    }
                }
            });

            itemView.setOnLongClickListener(new View.OnLongClickListener(){
                @Override
                public boolean onLongClick(View view) {
                    if(recyclerViewInterface != null){
                        int position = getAdapterPosition();
                        if(position!=RecyclerView.NO_POSITION){
                            recyclerViewInterface.onItemLongClick2(position);
                        }
                    }
                    return true;
                }
            });
        }
    }
}
