package edu.cis.ibcs_app;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.material.navigation.NavigationView;

import edu.cis.ibcs_app.Controllers.MainActivity;
import edu.cis.ibcs_app.Models.Breakfast;
import edu.cis.ibcs_app.Models.Lunch;
import edu.cis.ibcs_app.Models.NutritionFragment;
import edu.cis.ibcs_app.Models.Orders;
import edu.cis.ibcs_app.Models.Request;
import edu.cis.ibcs_app.Models.SimpleClient;
import edu.cis.ibcs_app.Models.Snack;
import edu.cis.ibcs_app.Utils.CISConstants;

public class CISUserActivity extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener {

    private DrawerLayout drawer;
    private String menu;
    private String cart;
    private String userID;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cisuser);

        Bundle b = getIntent().getExtras();
        if(b != null){
            userID = b.getString("userId");
        }

        getMenuItems();
        getCart();

        Toolbar toolbar = findViewById(R.id.toolbar);
        toolbar.setTitle("Your Orders");
        setSupportActionBar(toolbar);

        drawer = findViewById(R.id.drawer_layout);
        NavigationView navigationView  = findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(this);

        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawer.addDrawerListener(toggle);
        toggle.syncState();

        Orders orders = Orders.newInstance(userID);
        getSupportFragmentManager().beginTransaction().replace(R.id.fragment_container, orders).commit();
    }

    public void getCart(){
        try{
            Request req = new Request(CISConstants.GET_CART);
            req.addParam(CISConstants.USER_ID_PARAM,userID);
            cart = SimpleClient.makeRequest(CISConstants.HOST, req);
        }
        catch(Exception err){
            Toast messageToUser = Toast.makeText(this, "Error: "+err.toString(), Toast.LENGTH_LONG);
            messageToUser.show();
        }
    }

    public void getMenuItems(){
        try{
            Request req = new Request(CISConstants.GET_MENU);
            menu = SimpleClient.makeRequest(CISConstants.HOST, req);
        }
        catch(Exception err){
            Toast messageToUser = Toast.makeText(this, "Error: "+err.toString(), Toast.LENGTH_LONG);
            messageToUser.show();
        }
    }

    @Override
    public void onBackPressed(){
        if(drawer.isDrawerOpen(GravityCompat.START)){
            drawer.closeDrawer(GravityCompat.START);
        }
        else{
            super.onBackPressed();
        }
    }

    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {
        switch(menuItem.getItemId()){
            case R.id.nav_breakfast:
                Breakfast breakfast = Breakfast.newInstance(userID);
                getSupportFragmentManager().beginTransaction().replace(R.id.fragment_container, breakfast).commit();
                break;
            case R.id.nav_lunch:
                Lunch lunch = Lunch.newInstance(userID);
                getSupportFragmentManager().beginTransaction().replace(R.id.fragment_container, lunch).commit();
                break;
            case R.id.nav_snack:
                Snack snack = Snack.newInstance(userID);
                getSupportFragmentManager().beginTransaction().replace(R.id.fragment_container, snack).commit();
                break;
            case R.id.nav_cart:
                Orders orders = Orders.newInstance(userID);
                getSupportFragmentManager().beginTransaction().replace(R.id.fragment_container, orders).commit();
                break;
            case R.id.nav_logout:
                Intent nextScreen = new Intent(getBaseContext(), MainActivity.class);
                startActivity(nextScreen);
                break;
            case R.id.nav_calc:
                NutritionFragment nutritionFragment = NutritionFragment.newInstance();
                getSupportFragmentManager().beginTransaction().replace(R.id.fragment_container, nutritionFragment).commit();
                break;
        }
        drawer.closeDrawer(GravityCompat.START);
        return true;
    }
}