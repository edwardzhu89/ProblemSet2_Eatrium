package edu.cis.ibcs_app.Controllers;

import android.content.Intent;
import android.os.Bundle;
import android.os.StrictMode;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;


import java.io.IOException;

import edu.cis.ibcs_app.CISAdminActivity;
import edu.cis.ibcs_app.CISUserActivity;
import edu.cis.ibcs_app.Models.Request;
import edu.cis.ibcs_app.Models.SimpleClient;
import edu.cis.ibcs_app.Models.UserLoginFragment;
import edu.cis.ibcs_app.R;
import edu.cis.ibcs_app.UserManageFragment;
import edu.cis.ibcs_app.Utils.CISConstants;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_main);

        //This is not great, for extra credit you can fix this so that network calls happen on a different thread
        StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
        StrictMode.setThreadPolicy(policy);

        Button button = findViewById(R.id.button);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Request ping = new Request(CISConstants.PING);
                try {
                    String result = SimpleClient.makeRequest(CISConstants.HOST,ping);
                    Toast messageToUser = Toast.makeText(getBaseContext(), "Message: "+result,Toast.LENGTH_SHORT);
                    messageToUser.show();
                    System.out.println(result);
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        });
    }

    public void goToMarketPlace(View v){
        ConstraintLayout main = findViewById(R.id.main);
        main.setVisibility(View.GONE);
        UserLoginFragment login = UserLoginFragment.newInstance();
        getSupportFragmentManager().beginTransaction().replace(R.id.fragment_container, login).commit();
    }

    public void goToAdmin(View v){
        Intent nextScreen = new Intent(getBaseContext(), CISAdminActivity.class);
        startActivity(nextScreen);
    }

}