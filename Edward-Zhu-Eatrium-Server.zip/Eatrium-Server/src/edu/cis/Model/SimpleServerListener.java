package edu.cis.Model;

import edu.cis.Model.Request;

public interface SimpleServerListener
{
    String requestMade(Request req);
}
