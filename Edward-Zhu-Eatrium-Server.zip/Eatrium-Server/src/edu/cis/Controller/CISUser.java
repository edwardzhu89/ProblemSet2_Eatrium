package edu.cis.Controller;

import edu.cis.Model.CISConstants;

import java.util.ArrayList;

public class CISUser {

    private String userName;
    private String userId;
    private String yearLevel;
    private double money=50.0;
    private ArrayList<Order> orders;

    public CISUser(String name, String id, String year){

        userName=name;
        userId=id;
        yearLevel=year;
        orders=new ArrayList<Order>();

    }

    public CISUser(){
        userName="";
        userId="";
        yearLevel="";
        orders=new ArrayList<Order>();
    }

    public String addOrder(Order order){
        for(Order temp:orders){
            if(temp.getOrderID().equals(order.getOrderID())){
                return CISConstants.DUP_ORDER_ERR;
            }
        }
        orders.add(order);
        return "success";
    }
    public String removeOrder(String orderID){
        for(Order temp:orders){
            if(temp.getOrderID().equals(orderID)){
                orders.remove(temp);
                return "success";
            }
        }
        return CISConstants.ORDER_INVALID_ERR;
    }

    public String getOrder(String orderID){
        for(Order temp:orders){
            if(temp.getOrderID().equals(temp.getOrderID())){
                return temp.toString();
            }
        }
        return CISConstants.ORDER_INVALID_ERR;
    }

    public void setUserName(String name){
        userName=name;
    }

    public void setUserId(String id){
        userId=id;
    }

    public void setYearLevel(String year){
        yearLevel=year;
    }

    public void addMoney(double p){money+=p;}

    public void takeMoney(double p){
        money-=p;
    }

    public String getUserName(){
        return userName;
    }

    public String getUserId(){
        return userId;
    }

    public String getYearLevel(){
        return yearLevel;
    }

    public double getMoney(){return money;}

    public String toString(){
        String output="CISUser{userID=\'"+userId+"\', name=\'"+userName+"\', yearLevel=\'"+yearLevel+"\', orders= "+orderToString()+", money="+money+"}";
        return output;
    }

    public String orderToString(){
        String output="";
        for(Order temp: orders){
            output+=temp.toString();
        }
        return output;
    }

}