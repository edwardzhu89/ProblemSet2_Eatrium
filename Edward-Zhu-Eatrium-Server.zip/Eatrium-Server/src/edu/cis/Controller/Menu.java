package edu.cis.Controller;

import edu.cis.Model.CISConstants;

import java.util.ArrayList;

public class Menu {

    private ArrayList<MenuItem> eatriumItems;
    private String adminID;
    private ArrayList<String> itemNames;

    public Menu(){
        eatriumItems = new ArrayList<MenuItem>();
        itemNames=new ArrayList<String>();
        adminID="";
    }

    public Menu(String id){
        eatriumItems = new ArrayList<MenuItem>();
        itemNames=new ArrayList<String>();
        adminID=id;
    }

    public int size(){
        return eatriumItems.size();
    }

    public String addItem(MenuItem item){
        if(eatriumItems.contains(item)){
            return CISConstants.DUP_ITEM_ERR;
        }
        eatriumItems.add(item);
        itemNames.add(item.getItemName());
        return "success";
    }

    public String removeItem(String name){
        if(!itemNames.contains(name)){
            return CISConstants.INVALID_MENU_ITEM_ERR;
        }
        int index = itemNames.indexOf(name);
        eatriumItems.remove(index);
        itemNames.remove(index);
        return "success";
    }

    public ArrayList<MenuItem> getEatriumItems() {
        return eatriumItems;
    }

    public String toString(){
        String output="";
        for(MenuItem item: eatriumItems){
            output+=item.toString();
        }
        return output;
    }

    public MenuItem getItem(String id){
        for(MenuItem item:eatriumItems){
            if(item.getItemId().equals(id)){
                return item;
            }
        }
        return null;
    }
}
