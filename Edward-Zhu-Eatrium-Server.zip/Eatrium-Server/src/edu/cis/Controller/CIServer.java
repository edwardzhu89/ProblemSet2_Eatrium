/*
 * File: CIServer.java
 * ------------------------------
 * When it is finished, this program will implement a basic
 * ecommerce network management server.  Remember to update this comment!
 */

package edu.cis.Controller;

import acm.program.*;
import edu.cis.Model.CISConstants;
import edu.cis.Model.Request;
import edu.cis.Model.SimpleServerListener;
import edu.cis.Utils.SimpleServer;

import java.util.ArrayList;
import java.util.List;
//import stanford.cs106.net.SimpleServer;

public class CIServer extends ConsoleProgram
        implements SimpleServerListener
{

    private static List<CISUser> users=new ArrayList<>();
    private static List<String> ids=new ArrayList<>();
    private static List<String> allOrdersID = new ArrayList<>();

    /* The internet port to listen to requests on */
    private static final int PORT = 8000;

    private static Menu menu = new Menu();

    /* The server object. All you need to do is start it */
    private SimpleServer server = new SimpleServer(this, PORT);

    /**
     * Starts the server running so that when a program sends
     * a request to this server, the method requestMade is
     * called.
     */
    public void run()
    {
        println("Starting server on port " + PORT);
        server.start();
        users.clear();
        ids.clear();
        allOrdersID.clear();
        menu = new Menu();
    }

    /**
     * When a request is sent to this server, this method is
     * called. It must return a String.
     *
     * @param request a Request object built by SimpleServer from an
     *                incoming network request by the client
     */
    public String requestMade(Request request)
    {
        String cmd = request.getCommand();
        println(request.toString());

        // your code here.

        switch (request.getCommand()) {
            case CISConstants.CREATE_USER:
                return addUser(request);
            case CISConstants.ADD_MENU_ITEM:
                return addMenuItem(request);
            case CISConstants.PLACE_ORDER:
                return placeOrder(request);
            case CISConstants.DELETE_ORDER:
                return deleteOrder(request);
            case CISConstants.GET_USER:
                return getUser(request);
            case CISConstants.GET_ITEM:
                return getItem(request);
            case CISConstants.GET_ORDER:
                return getOrder(request);
            case CISConstants.DELETE_MENU_ITEM:
                return deleteMenuItem(request);
            case CISConstants.GET_MENU:
                return getMenu(request);
            case CISConstants.GET_CART:
                return getCart(request);
            case CISConstants.GET_ALL_USERS:
                return getAllUsers(request);
            case CISConstants.PING:
                final String PING_MSG = "Android Application Ping";

                //println is used instead of System.out.println to print to the server GUI
                println("   => " + PING_MSG);
                return PING_MSG;
        }

        return "Error: Unknown command " + cmd + ".";
    }

    public static String getAllUsers(Request req){
        String out="";
        for(CISUser user: users){
            out+=user.toString();
        }
        System.out.println(out);
        return out;
    }

    public static String getMenu(Request req){

        return menu.toString();

    }

    public static String addUser(Request req){

        CISUser newUser = new CISUser();

        String id=req.getParam(CISConstants.USER_ID_PARAM);
        String name=req.getParam(CISConstants.USER_NAME_PARAM);
        String year=req.getParam(CISConstants.YEAR_LEVEL_PARAM);

        if(id==null || name==null || year==null || name.isEmpty() || id.isEmpty() || year.isEmpty()){
            return CISConstants.PARAM_MISSING_ERR;
        }

        newUser.setUserId(id);
        newUser.setUserName(name);
        newUser.setYearLevel(year);

        if(ids.contains(id)){
            return CISConstants.DUP_USER_ERR;
        }

        ids.add(id);
        users.add(newUser);

        return "success";
    }

    public static String placeOrder(Request req){

        if(menu.size()==0){
            return CISConstants.EMPTY_MENU_ERR;
        }

        Order order = new Order();

        // Getting order parameters from request
        String orderName = req.getParam(CISConstants.ITEM_NAME_PARAM);
        String orderID = req.getParam(CISConstants.ORDER_ID_PARAM);
        String userID = req.getParam(CISConstants.USER_ID_PARAM);
        String type= req.getParam(CISConstants.ORDER_TYPE_PARAM);
        String itemID = req.getParam(CISConstants.ITEM_ID_PARAM);

        // If any of the parameters are empty, return missing parameter error
        if(orderName==null || orderID == null || userID == null || type == null || itemID == null){
            return CISConstants.PARAM_MISSING_ERR;
        }

        // Setting a new Order object with given parameters
        order.setOrderID(orderID);
        order.setItemID(itemID);
        order.setType(type);
        order.setItemName(orderName);

        // Getting MenuItem to get price and availabiity
        MenuItem itemOrdered=menu.getItem(itemID);

        // If no MenuItem in the menu has the ID given in itemID, return invalid menu item error
        if(itemOrdered==null){
            return CISConstants.INVALID_MENU_ITEM_ERR;
        }

        // If the MenuItem has no stock left, return sold out error
        if(itemOrdered.getAmountAvailable()==0){
            return CISConstants.SOLD_OUT_ERR;
        }

        // Finding the user to order food from the users ArrayList
        int index = ids.indexOf(userID);

        // When there is no user with the given ID, return no user found error
        if(index==-1){
            return CISConstants.USER_INVALID_ERR;
        }

        CISUser user = users.get(index);
        // If the user doesn't have enough money, return broke error
        if(user.getMoney()<itemOrdered.getPrice()){
            return CISConstants.USER_BROKE_ERR;
        }

        String output = user.addOrder(order);
        if(output.equals("success")) {
            // If another user has an order with the same orderID return duplicate error
            if (allOrdersID.contains(orderID)) {
                return CISConstants.DUP_ORDER_ID_ERR;
            }
            else{
                user.takeMoney(itemOrdered.getPrice());
                itemOrdered.setAmountAvailable(itemOrdered.getAmountAvailable()-1);
                return "success";
            }
        }

        // Otherwise add the orderID to the ArrayList
        allOrdersID.add(order.getOrderID());

        return output;
    }

    public static String deleteOrder(Request req){

        String userID=req.getParam(CISConstants.USER_ID_PARAM);
        String orderID=req.getParam(CISConstants.ORDER_ID_PARAM);
        String itemID=req.getParam(CISConstants.ITEM_ID_PARAM);

        CISUser user = users.get(ids.indexOf(userID));

        if(menu.getItem(itemID)==null){
            return CISConstants.INVALID_MENU_ITEM_ERR;
        }

        user.addMoney(menu.getItem(itemID).getPrice());
        menu.getItem(itemID).setAmountAvailable(menu.getItem(itemID).getAmountAvailable()+1);
        allOrdersID.remove(orderID);

        return user.removeOrder(orderID);
    }

    public static String addMenuItem(Request req){

        MenuItem newItem = new MenuItem();

        String name=req.getParam(CISConstants.ITEM_NAME_PARAM);
        String type=req.getParam(CISConstants.ITEM_TYPE_PARAM);
        String id=req.getParam(CISConstants.ITEM_ID_PARAM);
        String desc=req.getParam(CISConstants.DESC_PARAM);
        String nutrition=req.getParam(CISConstants.NUTRITION);

        double price=Double.parseDouble(req.getParam(CISConstants.PRICE_PARAM));

        if(name==null || type==null || id==null || desc==null || nutrition==null){
            return CISConstants.PARAM_MISSING_ERR;
        }

        if(menu.getItem(id)!=null){
            return CISConstants.DUP_ITEM_ERR;
        }

        String temp[] = nutrition.split(", ");
        ArrayList<Double> nutr = new ArrayList<>();
        for(int i=0;i<temp.length; i++){
            nutr.add(Double.parseDouble(temp[i]));
        }
        System.out.println(nutr.size());

        newItem.setItemId(id);
        newItem.setItemName(name);
        newItem.setDesc(desc);
        newItem.setPrice(price);
        newItem.setItemType(type);
        newItem.setAmountAvailable(10);
        newItem.setNutrition(nutr);

        return menu.addItem(newItem);
    }

    public static String deleteMenuItem(Request req){

        String name = req.getParam(CISConstants.ITEM_NAME_PARAM);
        return menu.removeItem(name);

    }

    public static String getUser(Request req){

        String userID=req.getParam(CISConstants.USER_ID_PARAM);

        if(!ids.contains(userID)){
            return CISConstants.USER_INVALID_ERR;
        }

        CISUser user = users.get(ids.indexOf(userID));
        return user.toString();

    }

    public static String getItem(Request req){

        String itemID=req.getParam(CISConstants.ITEM_ID_PARAM);
        MenuItem temp = menu.getItem(itemID);
        if(temp==null){
            return CISConstants.INVALID_MENU_ITEM_ERR;
        }
        else{
            return temp.toString();
        }
    }

    public static String getOrder(Request req){

        String userID=req.getParam(CISConstants.USER_ID_PARAM);
        String orderID=req.getParam(CISConstants.ORDER_ID_PARAM);
        CISUser user = users.get(ids.indexOf(userID));

        return user.getOrder(orderID);
    }

    public static String getCart(Request req){
        String userID=req.getParam(CISConstants.USER_ID_PARAM);

        if(userID==null){
            return CISConstants.PARAM_MISSING_ERR;
        }

        if(!ids.contains(userID)){
            return CISConstants.USER_INVALID_ERR;
        }

        CISUser user = users.get(ids.indexOf(userID));
        return user.orderToString();
    }

    public static void main(String[] args)
    {
        CIServer f = new CIServer();
        f.start(args);
    }
}
