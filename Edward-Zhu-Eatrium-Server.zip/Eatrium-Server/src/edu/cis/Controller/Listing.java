package edu.cis.Controller;

public class Listing {

    private String id;
    private String title;

    public Listing(){
        this.id="";
        this.title="";
    }

    public void setId(String id){
        this.id=id;
    }

    public void setTitle(String title){
        this.title=title;
    }

}
