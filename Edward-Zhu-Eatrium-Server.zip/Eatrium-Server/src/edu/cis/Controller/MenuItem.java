package edu.cis.Controller;

import java.util.ArrayList;

public class MenuItem {

    private String itemName;
    private String desc;
    private double price;
    private String itemId;
    private String itemType;
    private int amountAvailable;
    private ArrayList<Double> nutrition;

    public void setItemName(String name){
        itemName=name;
    }
    public void setDesc(String d){
        desc=d;
    }
    public void setPrice(double p){
        price =p;
    }
    public void setItemId(String id){
        itemId=id;
    }
    public void setItemType(String type){
        itemType=type;
    }
    public void setAmountAvailable(int amount){
        amountAvailable=amount;
    }
    public void setNutrition(ArrayList<Double> nutrition){
        this.nutrition=nutrition;
    }
    public String getItemName(){
        return itemName;
    }
    public String getDesc(){
        return desc;
    }
    public String getItemId(){
        return itemId;
    }
    public String getItemType(){
        return itemType;
    }
    public double getPrice(){
        return price;
    }
    public String toString(){
        String output="MenuItem{name='"+itemName+"', " + "description='"+desc+"', "+"price="+price+", "+"id='"+itemId+
                "', "+"amountAvailable="+amountAvailable+", "+"type='"+itemType+"', ";
        output+="nutrition={";
        for(int i=0;i<nutrition.size();i++){
            if(i!=nutrition.size()-1)output+=String.valueOf(nutrition.get(i))+", ";
            else{
                output+=String.valueOf(nutrition.get(i))+"}}";
            }
        }
        return output;
    }
    public int getAmountAvailable(){return amountAvailable;}
}
