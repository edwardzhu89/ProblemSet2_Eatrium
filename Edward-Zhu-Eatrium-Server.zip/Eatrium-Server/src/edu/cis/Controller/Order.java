package edu.cis.Controller;

public class Order {

    private String itemID;
    private String type;
    private String orderID;
    private String itemName;

    public Order(String orderID, String type, String itemID){
        this.itemID=itemID;
        this.type=type;
        this.orderID=orderID;
    }

    public Order(){
        this.itemID="";
        this.type="";
        this.orderID="";
    }

    public String toString(){
        String output="Order{" + "itemID=\'" + itemID + "\', type=\'" + type+"\', orderID=\'" + orderID+"\'" +", name=\'"+itemName+"\'}";
        return output;
    }

    public void setItemName(String itemName) {
        this.itemName = itemName;
    }

    public void setItemID(String itemID){
        this.itemID=itemID;
    }

    public void setType(String type){
        this.type=type;
    }

    public void setOrderID(String orderID){
        this.orderID=orderID;
    }

    public String getOrderID(){
        return orderID;
    }
}
