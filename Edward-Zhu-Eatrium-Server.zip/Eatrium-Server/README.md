# Eatrium-Client
# Student name: Edward Zhu
# Class: IB Computer Science 2022
# Project name: Eatrium App (Pset 2)
# Updated: Jan 4 2022
# Description: A mobile application where users may place orders for Eatrium food items (breakfast, snack, or lunch).
# Design document: https://docs.google.com/document/d/1NjaemyPZFMpWFFGefOlg_RLrZ0ZZ2sDo3UZYE8KB24g/edit?usp=sharing 